<?php
$x=6;
if($x%3==0){
    echo $x;
}else if(($x+1)%3==0){
    echo $x+1;
}
else if(($x+2)%3==0){
    echo $x+2;
}
?>