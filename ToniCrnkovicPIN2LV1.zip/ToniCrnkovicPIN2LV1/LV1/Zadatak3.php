<?php
$x=1;
while ($x!=10){
    $x=rand(1,20);
    echo $x."<br>";
}
?>