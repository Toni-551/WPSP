<?php
$n=100;
$x=1;
while ($x<=$n){
    echo "#";
    $b=1;
    while($b<=$x)
    {
        echo " ".$b;
        $b++;
    }
    echo "<br>";
    $x++;
}
?>